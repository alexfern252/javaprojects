# Spring Boot JPA MySQL - Building Rest CRUD API example

For more detail, please visit:
> [Spring Boot JPA - Building Rest CRUD API example](https://bezkoder.com/spring-boot-jpa-crud-rest-api/)

## Run Spring Boot application
```
mvn spring-boot:run
```
